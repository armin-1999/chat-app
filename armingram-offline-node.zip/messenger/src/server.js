'use strict';
const path = require('path');
const fs = require('fs');
const http = require('http');
const https = require('https');
const os = require('os');
const crypto = require('crypto');
const express = require('express');
const cookieParser = require('cookie-parser');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { WebSocketServer } = require('ws');
const { openDb } = require('./db');

// ---------- Config ----------
const PORT = parseInt(process.env.PORT || '3000', 10);
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const MAX_UPLOAD_MB = parseInt(process.env.MAX_UPLOAD_MB || '25', 10);
const COOKIE_SECURE = process.env.COOKIE_SECURE === 'true';
const SESSION_DAYS = parseInt(process.env.SESSION_DAYS || '30', 10);
const ALLOW_REGISTRATION = process.env.ALLOW_REGISTRATION !== 'false';
const APP_NAME = 'آرمینگرام';

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// In Docker we start as root only to fix ownership of the mounted data volume, then drop privileges.
if (process.getuid && process.getuid() === 0 && process.env.RUN_AS_UID) {
  const uid = parseInt(process.env.RUN_AS_UID, 10), gid = parseInt(process.env.RUN_AS_GID || process.env.RUN_AS_UID, 10);
  const chownR = p => { fs.chownSync(p, uid, gid); if (fs.statSync(p).isDirectory()) for (const f of fs.readdirSync(p)) chownR(path.join(p, f)); };
  try { chownR(DATA_DIR); } catch (e) { console.warn('chown failed:', e.message); }
  process.setgid(gid); process.setuid(uid);
}

// JWT secret: env var, otherwise generated once and persisted in the data dir.
function loadSecret() {
  if (process.env.JWT_SECRET && process.env.JWT_SECRET.length >= 16) return process.env.JWT_SECRET;
  const f = path.join(DATA_DIR, 'jwt_secret');
  if (fs.existsSync(f)) return fs.readFileSync(f, 'utf8').trim();
  const s = crypto.randomBytes(48).toString('hex');
  fs.writeFileSync(f, s, { mode: 0o600 });
  return s;
}
const JWT_SECRET = loadSecret();
const db = openDb(DATA_DIR);
const now = () => Date.now();

// ---------- Helpers ----------
const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹', AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
function normalizePhone(raw) {
  if (typeof raw !== 'string') return null;
  let p = raw.trim().replace(/[۰-۹]/g, d => FA_DIGITS.indexOf(d)).replace(/[٠-٩]/g, d => AR_DIGITS.indexOf(d));
  p = p.replace(/[\s\-()]/g, '');
  if (p.startsWith('+98')) p = '0' + p.slice(3);
  else if (p.startsWith('0098')) p = '0' + p.slice(4);
  else if (/^989\d{9}$/.test(p)) p = '0' + p.slice(2);
  else if (/^9\d{9}$/.test(p)) p = '0' + p;
  if (/^09\d{9}$/.test(p)) return p;          // Iranian mobile
  if (/^\+?\d{7,15}$/.test(p)) return p;       // general fallback
  return null;
}
function cleanName(n) {
  if (typeof n !== 'string') return '';
  return n.replace(/[\u0000-\u001f]/g, '').trim().slice(0, 64);
}
function publicUser(u) {
  if (!u) return null;
  return { id: u.id, phone: u.phone, displayName: u.display_name, lastSeen: u.last_seen, online: isOnline(u.id) };
}
function signToken(uid) {
  const u = q.userById.get(uid);
  return jwt.sign({ uid, tv: u ? u.token_version : 0 }, JWT_SECRET, { expiresIn: SESSION_DAYS + 'd' });
}
// Returns user id if token is valid and not revoked (password change bumps token_version).
function verifyToken(t) {
  try {
    const p = jwt.verify(t, JWT_SECRET);
    const u = q.userById.get(p.uid);
    return u && (p.tv || 0) === u.token_version ? u.id : null;
  } catch { return null; }
}
function setSession(res, uid) {
  res.cookie('session', signToken(uid), {
    httpOnly: true, sameSite: 'lax', secure: COOKIE_SECURE, maxAge: SESSION_DAYS * 864e5, path: '/',
  });
}
function parseCookies(header) {
  const out = {};
  (header || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return out;
}

// Simple in-memory rate limiter
const buckets = new Map();
function rateLimit(key, max, windowMs) {
  const t = now();
  let b = buckets.get(key);
  if (!b || b.reset < t) { b = { n: 0, reset: t + windowMs }; buckets.set(key, b); }
  b.n++;
  return b.n <= max;
}
setInterval(() => { const t = now(); for (const [k, b] of buckets) if (b.reset < t) buckets.delete(k); }, 60000).unref();

// ---------- Prepared statements ----------
const q = {
  userById: db.prepare('SELECT * FROM users WHERE id = ?'),
  userByPhone: db.prepare('SELECT * FROM users WHERE phone = ?'),
  insertUser: db.prepare('INSERT INTO users (phone, password_hash, display_name, created_at, last_seen) VALUES (?, ?, ?, ?, ?)'),
  updateName: db.prepare('UPDATE users SET display_name = ? WHERE id = ?'),
  updatePass: db.prepare('UPDATE users SET password_hash = ?, token_version = token_version + 1 WHERE id = ?'),
  touchSeen: db.prepare('UPDATE users SET last_seen = ? WHERE id = ?'),
  searchUsers: db.prepare("SELECT * FROM users WHERE phone LIKE ? AND id != ? ORDER BY phone LIMIT 20"),
  chatById: db.prepare('SELECT * FROM chats WHERE id = ?'),
  chatByKey: db.prepare('SELECT * FROM chats WHERE private_key = ?'),
  insertChat: db.prepare('INSERT INTO chats (type, title, private_key, created_by, created_at) VALUES (?, ?, ?, ?, ?)'),
  updateTitle: db.prepare('UPDATE chats SET title = ? WHERE id = ?'),
  member: db.prepare('SELECT * FROM chat_members WHERE chat_id = ? AND user_id = ?'),
  addMember: db.prepare('INSERT OR IGNORE INTO chat_members (chat_id, user_id, role, last_read_id, joined_at) VALUES (?, ?, ?, ?, ?)'),
  removeMember: db.prepare('DELETE FROM chat_members WHERE chat_id = ? AND user_id = ?'),
  memberIds: db.prepare('SELECT user_id FROM chat_members WHERE chat_id = ?'),
  members: db.prepare('SELECT u.*, m.role, m.last_read_id FROM chat_members m JOIN users u ON u.id = m.user_id WHERE m.chat_id = ? ORDER BY m.joined_at'),
  userChats: db.prepare(`
    SELECT c.*, m.last_read_id,
      (SELECT MAX(id) FROM messages WHERE chat_id = c.id) AS last_msg_id,
      (SELECT COUNT(*) FROM messages WHERE chat_id = c.id AND id > m.last_read_id AND (sender_id IS NULL OR sender_id != m.user_id)) AS unread
    FROM chat_members m JOIN chats c ON c.id = m.chat_id
    WHERE m.user_id = ?`),
  contactIds: db.prepare('SELECT DISTINCT m2.user_id FROM chat_members m1 JOIN chat_members m2 ON m1.chat_id = m2.chat_id WHERE m1.user_id = ? AND m2.user_id != ?'),
  setRead: db.prepare('UPDATE chat_members SET last_read_id = MAX(last_read_id, ?) WHERE chat_id = ? AND user_id = ?'),
  insertMsg: db.prepare('INSERT INTO messages (chat_id, sender_id, kind, body, file_id, created_at) VALUES (?, ?, ?, ?, ?, ?)'),
  msgById: db.prepare(`SELECT m.*, f.original_name, f.mime, f.size FROM messages m LEFT JOIN files f ON f.id = m.file_id WHERE m.id = ?`),
  history: db.prepare(`SELECT m.*, f.original_name, f.mime, f.size FROM messages m LEFT JOIN files f ON f.id = m.file_id
                       WHERE m.chat_id = ? AND m.id < ? ORDER BY m.id DESC LIMIT ?`),
  insertFile: db.prepare('INSERT INTO files (uploader_id, stored_name, original_name, mime, size, created_at) VALUES (?, ?, ?, ?, ?, ?)'),
  fileById: db.prepare('SELECT * FROM files WHERE id = ?'),
  fileAccess: db.prepare(`SELECT 1 FROM messages msg JOIN chat_members cm ON cm.chat_id = msg.chat_id
                          WHERE msg.file_id = ? AND cm.user_id = ? LIMIT 1`),
};

function publicMessage(m) {
  if (!m) return null;
  return {
    id: m.id, chatId: m.chat_id, senderId: m.sender_id, kind: m.kind, body: m.body, createdAt: m.created_at,
    file: m.file_id ? { id: m.file_id, name: m.original_name, mime: m.mime, size: m.size, url: `/api/files/${m.file_id}` } : null,
  };
}

function chatView(chatRow, forUserId) {
  const members = q.members.all(chatRow.id).map(u => ({ ...publicUser(u), role: u.role, lastReadId: u.last_read_id }));
  const me = members.find(m => m.id === forUserId);
  let title = chatRow.title, peer = null;
  if (chatRow.type === 'private') {
    peer = members.find(m => m.id !== forUserId) || me;
    title = peer ? peer.displayName : '';
  }
  const lastMsgId = chatRow.last_msg_id !== undefined ? chatRow.last_msg_id
    : (db.prepare('SELECT MAX(id) AS x FROM messages WHERE chat_id = ?').get(chatRow.id).x);
  let unread = chatRow.unread;
  if (unread === undefined) {
    unread = db.prepare('SELECT COUNT(*) AS n FROM messages WHERE chat_id = ? AND id > ? AND (sender_id IS NULL OR sender_id != ?)')
      .get(chatRow.id, me ? me.lastReadId : 0, forUserId).n;
  }
  return {
    id: chatRow.id, type: chatRow.type, title, peerId: peer ? peer.id : null, createdBy: chatRow.created_by,
    createdAt: chatRow.created_at, members, unread,
    lastMessage: lastMsgId ? publicMessage(q.msgById.get(lastMsgId)) : null,
  };
}

function createMessage(chatId, senderId, kind, body, fileId) {
  const r = q.insertMsg.run(chatId, senderId, kind, body, fileId || null, now());
  const id = Number(r.lastInsertRowid);
  if (senderId) q.setRead.run(id, chatId, senderId);
  const msg = publicMessage(q.msgById.get(id));
  broadcastToChat(chatId, { type: 'message', message: msg });
  return msg;
}

function validateOutgoing(userId, chatId, text, fileId) {
  chatId = parseInt(chatId, 10);
  if (!chatId || !q.member.get(chatId, userId)) return { error: 'شما عضو این گفتگو نیستید' };
  text = typeof text === 'string' ? text.replace(/\u0000/g, '').trim() : '';
  if (text.length > 4000) return { error: 'پیام خیلی طولانی است' };
  let kind = 'text';
  if (fileId) {
    const f = q.fileById.get(parseInt(fileId, 10));
    if (!f || f.uploader_id !== userId) return { error: 'فایل نامعتبر است' };
    fileId = f.id;
    kind = f.mime.startsWith('image/') ? 'image' : 'file';
  } else fileId = null;
  if (!text && !fileId) return { error: 'پیام خالی است' };
  return { chatId, text, fileId, kind };
}

// ---------- App ----------
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', process.env.TRUST_PROXY === 'true' ? 1 : false);
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; img-src 'self' blob: data:; style-src 'self'; script-src 'self'; connect-src 'self' ws: wss:; font-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'");
  next();
});

function auth(req, res, next) {
  let token = req.cookies.session;
  const h = req.headers.authorization;
  if (!token && h && h.startsWith('Bearer ')) token = h.slice(7);
  const uid = token && verifyToken(token);
  const user = uid && q.userById.get(uid);
  if (!user) return res.status(401).json({ error: 'ابتدا وارد شوید' });
  req.user = user;
  next();
}

const api = express.Router();

api.get('/health', (req, res) => res.json({ ok: true, app: APP_NAME, time: now() }));
api.get('/config', (req, res) => res.json({ appName: APP_NAME, allowRegistration: ALLOW_REGISTRATION, maxUploadMb: MAX_UPLOAD_MB }));

api.post('/register', async (req, res) => {
  if (!ALLOW_REGISTRATION) return res.status(403).json({ error: 'ثبت‌نام غیرفعال است' });
  if (!rateLimit('reg:' + req.ip, 10, 3600e3)) return res.status(429).json({ error: 'تعداد درخواست‌ها زیاد است؛ بعداً تلاش کنید' });
  const phone = normalizePhone(req.body.phone);
  const password = req.body.password;
  const displayName = cleanName(req.body.displayName) || phone;
  if (!phone) return res.status(400).json({ error: 'شماره تلفن نامعتبر است (مثال: 09123456789)' });
  if (typeof password !== 'string' || password.length < 6 || password.length > 128)
    return res.status(400).json({ error: 'رمز عبور باید حداقل ۶ کاراکتر باشد' });
  if (q.userByPhone.get(phone)) return res.status(409).json({ error: 'این شماره قبلاً ثبت شده است' });
  const hash = await bcrypt.hash(password, 11);
  let id;
  try { id = Number(q.insertUser.run(phone, hash, displayName, now(), now()).lastInsertRowid); }
  catch { return res.status(409).json({ error: 'این شماره قبلاً ثبت شده است' }); }
  setSession(res, id);
  res.json({ user: publicUser(q.userById.get(id)), token: signToken(id) });
});

api.post('/login', async (req, res) => {
  const phone = normalizePhone(req.body.phone);
  if (!rateLimit('login:' + req.ip, 30, 600e3) || (phone && !rateLimit('loginp:' + phone, 10, 600e3)))
    return res.status(429).json({ error: 'تلاش‌های زیاد؛ چند دقیقه دیگر دوباره امتحان کنید' });
  const user = phone && q.userByPhone.get(phone);
  const ok = user && typeof req.body.password === 'string' && await bcrypt.compare(req.body.password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'شماره یا رمز عبور اشتباه است' });
  setSession(res, user.id);
  res.json({ user: publicUser(user), token: signToken(user.id) });
});

api.post('/logout', (req, res) => { res.clearCookie('session', { path: '/' }); res.json({ ok: true }); });

// Like /me but never 401s: used by the frontend at boot to check for an existing session.
api.get('/session', (req, res) => {
  let token = req.cookies.session;
  const uid = token && verifyToken(token);
  res.json({ user: uid ? publicUser(q.userById.get(uid)) : null });
});
api.get('/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));
api.patch('/me', auth, (req, res) => {
  const name = cleanName(req.body.displayName);
  if (!name) return res.status(400).json({ error: 'نام نمایشی را وارد کنید' });
  q.updateName.run(name, req.user.id);
  const u = publicUser(q.userById.get(req.user.id));
  notifyUsers([req.user.id, ...contactsOf(req.user.id)], { type: 'user', user: u });
  res.json({ user: u });
});
api.post('/me/password', auth, async (req, res) => {
  const { oldPassword, newPassword } = req.body;
  if (typeof oldPassword !== 'string' || !(await bcrypt.compare(oldPassword, req.user.password_hash)))
    return res.status(400).json({ error: 'رمز فعلی اشتباه است' });
  if (typeof newPassword !== 'string' || newPassword.length < 6 || newPassword.length > 128)
    return res.status(400).json({ error: 'رمز جدید باید حداقل ۶ کاراکتر باشد' });
  q.updatePass.run(await bcrypt.hash(newPassword, 11), req.user.id);
  setSession(res, req.user.id); // other sessions are revoked, keep this one
  res.json({ ok: true });
});

api.get('/users/search', auth, (req, res) => {
  let raw = String(req.query.phone || '').trim();
  const norm = normalizePhone(raw);
  let digits = (norm || raw).replace(/[۰-۹]/g, d => FA_DIGITS.indexOf(d)).replace(/[^\d+]/g, '');
  if (digits.length < 4) return res.json({ users: [] });
  res.json({ users: q.searchUsers.all('%' + digits + '%', req.user.id).map(publicUser) });
});

api.get('/chats', auth, (req, res) => {
  const chats = q.userChats.all(req.user.id).map(c => chatView(c, req.user.id));
  chats.sort((a, b) => ((b.lastMessage ? b.lastMessage.createdAt : b.createdAt) - (a.lastMessage ? a.lastMessage.createdAt : a.createdAt)));
  res.json({ chats });
});

api.get('/chats/:id', auth, (req, res) => {
  const c = q.chatById.get(parseInt(req.params.id, 10));
  if (!c || !q.member.get(c.id, req.user.id)) return res.status(404).json({ error: 'گفتگو پیدا نشد' });
  res.json({ chat: chatView(c, req.user.id) });
});

api.post('/chats/private', auth, (req, res) => {
  const other = q.userById.get(parseInt(req.body.userId, 10));
  if (!other) return res.status(404).json({ error: 'کاربر پیدا نشد' });
  const a = Math.min(req.user.id, other.id), b = Math.max(req.user.id, other.id);
  const key = `${a}:${b}`;
  let chat = q.chatByKey.get(key);
  if (!chat) {
    const id = Number(q.insertChat.run('private', null, key, req.user.id, now()).lastInsertRowid);
    q.addMember.run(id, a, 'member', 0, now());
    if (b !== a) q.addMember.run(id, b, 'member', 0, now());
    chat = q.chatById.get(id);
  }
  res.json({ chat: chatView(chat, req.user.id) });
});

api.post('/chats/group', auth, (req, res) => {
  const title = cleanName(req.body.title);
  if (!title) return res.status(400).json({ error: 'نام گروه را وارد کنید' });
  const ids = Array.isArray(req.body.memberIds) ? req.body.memberIds.map(Number).filter(Boolean) : [];
  const id = Number(q.insertChat.run('group', title, null, req.user.id, now()).lastInsertRowid);
  q.addMember.run(id, req.user.id, 'admin', 0, now());
  for (const uid of new Set(ids)) if (q.userById.get(uid)) q.addMember.run(id, uid, 'member', 0, now());
  createMessage(id, null, 'system', `گروه «${title}» توسط ${req.user.display_name} ساخته شد`);
  pushChatToMembers(id);
  res.json({ chat: chatView(q.chatById.get(id), req.user.id) });
});

api.patch('/chats/:id', auth, (req, res) => {
  const c = q.chatById.get(parseInt(req.params.id, 10));
  if (!c || c.type !== 'group' || !q.member.get(c.id, req.user.id)) return res.status(404).json({ error: 'گروه پیدا نشد' });
  const title = cleanName(req.body.title);
  if (!title) return res.status(400).json({ error: 'نام گروه را وارد کنید' });
  q.updateTitle.run(title, c.id);
  createMessage(c.id, null, 'system', `${req.user.display_name} نام گروه را به «${title}» تغییر داد`);
  pushChatToMembers(c.id);
  res.json({ chat: chatView(q.chatById.get(c.id), req.user.id) });
});

api.post('/chats/:id/members', auth, (req, res) => {
  const c = q.chatById.get(parseInt(req.params.id, 10));
  if (!c || c.type !== 'group' || !q.member.get(c.id, req.user.id)) return res.status(404).json({ error: 'گروه پیدا نشد' });
  const ids = Array.isArray(req.body.userIds) ? req.body.userIds.map(Number).filter(Boolean) : [];
  const added = [];
  for (const uid of new Set(ids)) {
    const u = q.userById.get(uid);
    if (u && !q.member.get(c.id, uid)) { q.addMember.run(c.id, uid, 'member', 0, now()); added.push(u.display_name); }
  }
  if (added.length) {
    createMessage(c.id, null, 'system', `${req.user.display_name}، ${added.join('، ')} را به گروه اضافه کرد`);
    pushChatToMembers(c.id);
  }
  res.json({ chat: chatView(q.chatById.get(c.id), req.user.id) });
});

api.post('/chats/:id/leave', auth, (req, res) => {
  const c = q.chatById.get(parseInt(req.params.id, 10));
  if (!c || c.type !== 'group' || !q.member.get(c.id, req.user.id)) return res.status(404).json({ error: 'گروه پیدا نشد' });
  q.removeMember.run(c.id, req.user.id);
  createMessage(c.id, null, 'system', `${req.user.display_name} گروه را ترک کرد`);
  pushChatToMembers(c.id);
  notifyUsers([req.user.id], { type: 'chatRemoved', chatId: c.id });
  res.json({ ok: true });
});

api.get('/chats/:id/messages', auth, (req, res) => {
  const chatId = parseInt(req.params.id, 10);
  if (!q.member.get(chatId, req.user.id)) return res.status(404).json({ error: 'گفتگو پیدا نشد' });
  const before = parseInt(req.query.before, 10) || Number.MAX_SAFE_INTEGER;
  const limit = Math.min(parseInt(req.query.limit, 10) || 50, 200);
  const rows = q.history.all(chatId, before, limit).reverse().map(publicMessage);
  res.json({ messages: rows, hasMore: rows.length === limit });
});

api.post('/chats/:id/messages', auth, (req, res) => {
  const v = validateOutgoing(req.user.id, req.params.id, req.body.text, req.body.fileId);
  if (v.error) return res.status(400).json({ error: v.error });
  res.json({ message: createMessage(v.chatId, req.user.id, v.kind, v.text, v.fileId) });
});

api.post('/chats/:id/read', auth, (req, res) => {
  markRead(req.user.id, parseInt(req.params.id, 10), parseInt(req.body.messageId, 10));
  res.json({ ok: true });
});

function markRead(userId, chatId, messageId) {
  if (!chatId || !messageId || !q.member.get(chatId, userId)) return;
  q.setRead.run(messageId, chatId, userId);
  broadcastToChat(chatId, { type: 'read', chatId, userId, messageId });
}

// Uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const d = new Date();
    const sub = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    fs.mkdirSync(path.join(UPLOAD_DIR, sub), { recursive: true });
    cb(null, path.join(UPLOAD_DIR, sub));
  },
  filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex')),
});
const upload = multer({ storage, limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 1 } });
api.post('/upload', auth, (req, res) => {
  if (!rateLimit('up:' + req.user.id, 120, 3600e3)) return res.status(429).json({ error: 'تعداد آپلودها زیاد است' });
  upload.single('file')(req, res, err => {
    if (err) return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? `حداکثر حجم فایل ${MAX_UPLOAD_MB} مگابایت است` : 'خطا در آپلود' });
    if (!req.file) return res.status(400).json({ error: 'فایلی انتخاب نشده' });
    // multer decodes filename as latin1; convert to utf8 for Persian names
    let name = Buffer.from(req.file.originalname, 'latin1').toString('utf8').replace(/[\/\\\u0000-\u001f]/g, '_').slice(0, 200) || 'file';
    const rel = path.relative(UPLOAD_DIR, req.file.path);
    const mime = /^[\w.+-]+\/[\w.+-]+$/.test(req.file.mimetype) ? req.file.mimetype : 'application/octet-stream';
    const id = Number(q.insertFile.run(req.user.id, rel, name, mime, req.file.size, now()).lastInsertRowid);
    res.json({ file: { id, name, mime, size: req.file.size, url: `/api/files/${id}` } });
  });
});

const INLINE_SAFE = new Set(['image/png', 'image/jpeg', 'image/gif', 'image/webp', 'image/avif', 'image/bmp',
  'video/mp4', 'video/webm', 'audio/mpeg', 'audio/ogg', 'audio/webm', 'audio/wav', 'audio/mp4', 'application/pdf']);
api.get('/files/:id', auth, (req, res) => {
  const f = q.fileById.get(parseInt(req.params.id, 10));
  if (!f) return res.status(404).json({ error: 'فایل پیدا نشد' });
  if (f.uploader_id !== req.user.id && !q.fileAccess.get(f.id, req.user.id)) return res.status(403).json({ error: 'دسترسی ندارید' });
  const full = path.join(UPLOAD_DIR, f.stored_name);
  if (!full.startsWith(UPLOAD_DIR + path.sep) || !fs.existsSync(full)) return res.status(404).json({ error: 'فایل پیدا نشد' });
  const inline = INLINE_SAFE.has(f.mime) && req.query.download !== '1';
  res.setHeader('Content-Type', inline ? f.mime : 'application/octet-stream');
  res.setHeader('Content-Disposition', `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(f.original_name)}`);
  res.setHeader('Cache-Control', 'private, max-age=31536000, immutable');
  res.setHeader('Content-Security-Policy', "default-src 'none'; sandbox");
  res.sendFile(full);
});

app.use('/api', api);
app.use('/api', (req, res) => res.status(404).json({ error: 'یافت نشد' }));
app.use(express.static(path.join(__dirname, '..', 'public'), {
  setHeaders: (res, p) => {
    if (p.endsWith('sw.js') || p.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache');
    if (p.endsWith('.webmanifest')) res.setHeader('Content-Type', 'application/manifest+json');
  },
}));
app.get(/^\/(?!api|ws).*/, (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));
app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: 'خطای سرور' }); });

// ---------- WebSocket ----------
// Optional built-in HTTPS (useful on a LAN without Caddy/nginx): set TLS_CERT and TLS_KEY to PEM file paths.
const TLS = process.env.TLS_CERT && process.env.TLS_KEY;
const server = TLS
  ? https.createServer({ cert: fs.readFileSync(process.env.TLS_CERT), key: fs.readFileSync(process.env.TLS_KEY) }, app)
  : http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 64 * 1024 });
const sockets = new Map(); // userId -> Set<ws>

function isOnline(uid) { const s = sockets.get(uid); return !!(s && s.size); }
function contactsOf(uid) { return q.contactIds.all(uid, uid).map(r => r.user_id); }
function send(ws, obj) { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); }
function notifyUsers(uids, obj) {
  const data = JSON.stringify(obj);
  for (const uid of new Set(uids)) { const set = sockets.get(uid); if (set) for (const ws of set) if (ws.readyState === 1) ws.send(data); }
}
function broadcastToChat(chatId, obj) { notifyUsers(q.memberIds.all(chatId).map(r => r.user_id), obj); }
function pushChatToMembers(chatId) {
  const c = q.chatById.get(chatId);
  for (const { user_id } of q.memberIds.all(chatId)) notifyUsers([user_id], { type: 'chat', chat: chatView(c, user_id) });
}
function broadcastPresence(uid) {
  const u = q.userById.get(uid);
  notifyUsers(contactsOf(uid), { type: 'presence', userId: uid, online: isOnline(uid), lastSeen: u.last_seen });
}

wss.on('connection', (ws, req) => {
  const cookies = parseCookies(req.headers.cookie);
  let token = cookies.session;
  if (!token) { try { token = new URL(req.url, 'http://x').searchParams.get('token'); } catch {} }
  const uid = token && verifyToken(token);
  if (!uid || !q.userById.get(uid)) { ws.close(4001, 'unauthorized'); return; }
  ws.uid = uid; ws.isAlive = true;
  if (!sockets.has(uid)) sockets.set(uid, new Set());
  const first = sockets.get(uid).size === 0;
  sockets.get(uid).add(ws);
  q.touchSeen.run(now(), uid);
  if (first) broadcastPresence(uid);
  send(ws, { type: 'hello', userId: uid });

  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', raw => {
    if (!rateLimit('ws:' + uid, 60, 10e3)) return send(ws, { type: 'error', error: 'ارسال بیش از حد سریع' });
    let m; try { m = JSON.parse(raw.toString()); } catch { return; }
    if (!m || typeof m !== 'object') return;
    if (m.type === 'send') {
      const v = validateOutgoing(uid, m.chatId, m.text, m.fileId);
      if (v.error) return send(ws, { type: 'error', clientId: m.clientId, error: v.error });
      const msg = createMessage(v.chatId, uid, v.kind, v.text, v.fileId);
      send(ws, { type: 'ack', clientId: m.clientId, message: msg });
    } else if (m.type === 'read') {
      markRead(uid, parseInt(m.chatId, 10), parseInt(m.messageId, 10));
    } else if (m.type === 'typing') {
      const chatId = parseInt(m.chatId, 10);
      if (chatId && q.member.get(chatId, uid)) {
        notifyUsers(q.memberIds.all(chatId).map(r => r.user_id).filter(x => x !== uid), { type: 'typing', chatId, userId: uid });
      }
    } else if (m.type === 'ping') send(ws, { type: 'pong' });
  });
  ws.on('close', () => {
    const set = sockets.get(uid);
    if (set) { set.delete(ws); if (!set.size) { sockets.delete(uid); q.touchSeen.run(now(), uid); broadcastPresence(uid); } }
  });
  ws.on('error', () => {});
});

const hb = setInterval(() => {
  for (const ws of wss.clients) { if (!ws.isAlive) { ws.terminate(); continue; } ws.isAlive = false; try { ws.ping(); } catch {} }
}, 30000);
wss.on('close', () => clearInterval(hb));

const HOST = process.env.HOST || '0.0.0.0';
server.listen(PORT, HOST, () => {
  const proto = TLS ? 'https' : 'http';
  console.log(`${APP_NAME} (armingram) listening on ${HOST}:${PORT}, data dir: ${DATA_DIR}`);
  console.log(`  local:   ${proto}://localhost:${PORT}`);
  for (const list of Object.values(os.networkInterfaces()))
    for (const a of list || []) if (a.family === 'IPv4' && !a.internal) console.log(`  network: ${proto}://${a.address}:${PORT}`);
});

function shutdown() { console.log('shutting down'); server.close(); try { db.close(); } catch {} process.exit(0); }
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
