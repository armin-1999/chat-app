'use strict';
// آرمینگرام - frontend (vanilla JS, no external dependencies)
(() => {
  const $ = id => document.getElementById(id);
  const state = {
    me: null, chats: new Map(), activeId: null, messages: new Map(), hasMore: new Map(),
    ws: null, wsRetry: 0, pending: new Map(), typing: new Map(), mode: 'login', filter: '',
  };

  // ---------- utils ----------
  const faNum = new Intl.NumberFormat('fa-IR', { useGrouping: false });
  const toFa = s => String(s).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
  const timeFmt = new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit', hour12: false });
  const dayFmt = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { day: 'numeric', month: 'long', year: 'numeric' });
  const shortDayFmt = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { day: 'numeric', month: 'short' });
  const fmtTime = t => timeFmt.format(new Date(t));
  function fmtListTime(t) {
    const d = new Date(t), n = new Date();
    return d.toDateString() === n.toDateString() ? fmtTime(t) : shortDayFmt.format(d);
  }
  function fmtLastSeen(t) {
    if (!t) return 'مدتی پیش';
    const diff = (Date.now() - t) / 1000;
    if (diff < 60) return 'آخرین بازدید لحظاتی پیش';
    if (diff < 3600) return `آخرین بازدید ${toFa(Math.floor(diff / 60))} دقیقه پیش`;
    if (new Date(t).toDateString() === new Date().toDateString()) return `آخرین بازدید امروز ساعت ${fmtTime(t)}`;
    return `آخرین بازدید ${shortDayFmt.format(new Date(t))}`;
  }
  function fmtSize(b) {
    if (b < 1024) return toFa(b) + ' بایت';
    if (b < 1048576) return toFa((b / 1024).toFixed(1)) + ' کیلوبایت';
    return toFa((b / 1048576).toFixed(1)) + ' مگابایت';
  }
  const colorOf = id => 'c' + (Math.abs(Number(id) || 0) % 7);
  const initial = name => (String(name || '?').trim()[0] || '?').toUpperCase();
  function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function avatar(name, id, extra) { const a = el('div', `avatar ${colorOf(id)} ${extra || ''}`, initial(name)); return a; }
  let toastTimer;
  function toast(msg) { const t = $('toast'); t.textContent = msg; t.classList.remove('hidden'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.add('hidden'), 3000); }

  async function api(path, opts = {}) {
    const o = { method: opts.method || 'GET', headers: {}, credentials: 'same-origin' };
    if (opts.body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(opts.body); }
    let res;
    try { res = await fetch('/api' + path, o); } catch { throw new Error('ارتباط با سرور برقرار نشد'); }
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && path !== '/login' && path !== '/me') { logoutLocal(); }
    if (!res.ok) throw new Error(data.error || 'خطا');
    return data;
  }

  // ---------- auth ----------
  function setMode(mode) {
    state.mode = mode;
    $('tab-login').classList.toggle('active', mode === 'login');
    $('tab-register').classList.toggle('active', mode === 'register');
    $('name-row').classList.toggle('hidden', mode !== 'register');
    $('auth-submit').textContent = mode === 'login' ? 'ورود' : 'ثبت‌نام';
    $('auth-pass').autocomplete = mode === 'login' ? 'current-password' : 'new-password';
    $('auth-error').textContent = '';
  }
  $('tab-login').onclick = () => setMode('login');
  $('tab-register').onclick = () => setMode('register');
  $('auth-form').onsubmit = async e => {
    e.preventDefault();
    const btn = $('auth-submit'); btn.disabled = true; $('auth-error').textContent = '';
    try {
      const body = { phone: $('auth-phone').value, password: $('auth-pass').value };
      if (state.mode === 'register') body.displayName = $('auth-name').value;
      const r = await api(state.mode === 'login' ? '/login' : '/register', { method: 'POST', body });
      state.me = r.user; $('auth-pass').value = '';
      await enterApp();
    } catch (err) { $('auth-error').textContent = err.message; }
    finally { btn.disabled = false; }
  };
  function logoutLocal() {
    state.me = null; state.chats.clear(); state.messages.clear(); state.activeId = null;
    if (state.ws) { state.ws.onclose = null; state.ws.close(); state.ws = null; }
    $('main').classList.add('hidden'); $('auth').classList.remove('hidden');
  }

  async function enterApp() {
    $('auth').classList.add('hidden'); $('main').classList.remove('hidden');
    renderMe();
    await loadChats();
    connectWs();
    const h = parseInt(location.hash.slice(1), 10);
    if (h && state.chats.has(h)) openChat(h);
  }
  function renderMe() {
    $('menu-name').textContent = state.me.displayName;
    $('menu-phone').textContent = toFa(state.me.phone);
    const a = $('menu-avatar'); a.className = `avatar sm ${colorOf(state.me.id)}`; a.textContent = initial(state.me.displayName);
  }

  // ---------- chats ----------
  async function loadChats() {
    const r = await api('/chats');
    state.chats.clear();
    r.chats.forEach(c => state.chats.set(c.id, c));
    renderChatList();
  }
  function chatTime(c) { return c.lastMessage ? c.lastMessage.createdAt : c.createdAt; }
  function peerOf(c) { return c.type === 'private' ? c.members.find(m => m.id === c.peerId) : null; }
  function memberName(c, uid) { const m = c.members.find(x => x.id === uid); return m ? m.displayName : 'کاربر'; }
  function previewText(c) {
    const m = c.lastMessage; if (!m) return c.type === 'group' ? 'گروه ساخته شد' : 'گفتگو را شروع کنید';
    let t = m.kind === 'image' ? '🖼 تصویر' + (m.body ? ': ' + m.body : '') : m.kind === 'file' ? '📎 ' + (m.file ? m.file.name : 'فایل') : m.body;
    if (m.kind !== 'system' && c.type === 'group') t = (m.senderId === state.me.id ? 'شما' : memberName(c, m.senderId)) + ': ' + t;
    else if (m.kind !== 'system' && m.senderId === state.me.id) t = 'شما: ' + t;
    return t;
  }
  function renderChatList() {
    const ul = $('chat-list'); ul.textContent = '';
    const f = state.filter.trim().toLowerCase();
    const list = [...state.chats.values()].sort((a, b) => chatTime(b) - chatTime(a))
      .filter(c => !f || (c.title || '').toLowerCase().includes(f) || (peerOf(c) && peerOf(c).phone.includes(f)));
    for (const c of list) {
      const li = el('li', 'chat-item' + (c.id === state.activeId ? ' active' : ''));
      const peer = peerOf(c);
      li.appendChild(avatar(c.type === 'group' ? c.title : c.title, c.type === 'group' ? -c.id : c.peerId, peer && peer.online ? 'online' : ''));
      if (c.type === 'group') li.firstChild.textContent = '👥';
      const meta = el('div', 'meta');
      const r1 = el('div', 'row'); r1.append(el('span', 'name', c.title), el('span', 'time', fmtListTime(chatTime(c))));
      const r2 = el('div', 'row');
      const typing = state.typing.get(c.id);
      r2.append(el('span', 'preview', typing && typing.until > Date.now() ? 'در حال نوشتن…' : previewText(c)));
      if (c.unread > 0 && c.id !== state.activeId) r2.append(el('span', 'badge', toFa(c.unread > 99 ? '99+' : c.unread)));
      meta.append(r1, r2); li.append(meta);
      li.onclick = () => openChat(c.id);
      ul.appendChild(li);
    }
    $('empty-list').classList.toggle('hidden', state.chats.size > 0);
    const total = [...state.chats.values()].reduce((s, c) => s + (c.id === state.activeId ? 0 : c.unread || 0), 0);
    document.title = total ? `(${toFa(total)}) آرمینگرام` : 'آرمینگرام';
  }
  $('chat-filter').oninput = e => { state.filter = e.target.value; renderChatList(); };

  async function openChat(id) {
    const c = state.chats.get(id); if (!c) return;
    state.activeId = id;
    if (location.hash !== '#' + id) history.replaceState(null, '', '#' + id);
    $('main').classList.add('in-chat');
    $('chat-empty').classList.add('hidden'); $('chat-view').classList.remove('hidden');
    renderHeader();
    if (!state.messages.has(id)) {
      $('messages').textContent = '';
      try {
        const r = await api(`/chats/${id}/messages?limit=50`);
        state.messages.set(id, r.messages); state.hasMore.set(id, r.hasMore);
      } catch (e) { toast(e.message); return; }
    }
    if (state.activeId !== id) return;
    renderMessages(true);
    markActiveRead();
    renderChatList();
    if (window.innerWidth > 760) $('msg-input').focus();
  }
  function renderHeader() {
    const c = state.chats.get(state.activeId); if (!c) return;
    $('chat-title').textContent = c.title;
    const a = $('chat-avatar'); const peer = peerOf(c);
    a.className = `avatar ${colorOf(c.type === 'group' ? -c.id : c.peerId)}`;
    a.textContent = c.type === 'group' ? '👥' : initial(c.title);
    const typing = state.typing.get(c.id);
    let status;
    if (typing && typing.until > Date.now()) status = c.type === 'group' ? `${memberName(c, typing.userId)} در حال نوشتن…` : 'در حال نوشتن…';
    else if (c.type === 'group') { const on = c.members.filter(m => m.online).length; status = `${toFa(c.members.length)} عضو` + (on ? `، ${toFa(on)} آنلاین` : ''); }
    else if (peer && peer.id === state.me.id) status = 'پیام‌های ذخیره‌شده';
    else status = peer && peer.online ? 'آنلاین' : fmtLastSeen(peer && peer.lastSeen);
    $('chat-status').textContent = status;
  }
  $('btn-back').onclick = () => {
    state.activeId = null; history.replaceState(null, '', location.pathname);
    $('main').classList.remove('in-chat'); $('chat-view').classList.add('hidden'); $('chat-empty').classList.remove('hidden');
    renderChatList();
  };

  // ---------- messages ----------
  function readByOthers(c, m) {
    if (m.senderId !== state.me.id) return false;
    return c.members.some(x => x.id !== state.me.id && x.lastReadId >= m.id);
  }
  function renderMessage(c, m, prev) {
    if (m.kind === 'system') return el('div', 'sys', m.body);
    const mine = m.senderId === state.me.id;
    const div = el('div', 'msg' + (mine ? ' out' : '') + (m.pending ? ' pending' : ''));
    div.dataset.id = m.id;
    if (c.type === 'group' && !mine && (!prev || prev.senderId !== m.senderId || prev.kind === 'system'))
      div.appendChild(el('div', 'sender ' + colorOf(m.senderId), memberName(c, m.senderId)));
    if (m.file) {
      if (m.kind === 'image') {
        const img = el('img', 'photo'); img.src = m.file.url; img.alt = m.file.name; img.loading = 'lazy';
        img.onclick = () => { $('lightbox-img').src = m.file.url; $('lightbox').classList.remove('hidden'); };
        img.onload = () => { if (isNearBottom()) scrollBottom(); };
        div.appendChild(img);
      } else {
        const a = el('a', 'filebox'); a.href = m.file.url + '?download=1'; a.download = m.file.name;
        const info = el('div'); info.append(el('div', 'filename', m.file.name), el('div', 'muted small', fmtSize(m.file.size)));
        a.append(el('div', 'fileicon', '⬇'), info); div.appendChild(a);
      }
    }
    if (m.body) div.appendChild(el('div', 'text', m.body));
    const foot = el('div', 'foot');
    foot.append(el('span', null, fmtTime(m.createdAt)));
    if (mine) foot.append(el('span', 'ticks', m.pending ? '🕓' : readByOthers(c, m) ? '✓✓' : '✓'));
    div.appendChild(foot);
    return div;
  }
  function isNearBottom() { const b = $('messages'); return b.scrollHeight - b.scrollTop - b.clientHeight < 120; }
  function scrollBottom() { const b = $('messages'); b.scrollTop = b.scrollHeight; }
  function renderMessages(toBottom) {
    const c = state.chats.get(state.activeId); if (!c) return;
    const box = $('messages'); const near = isNearBottom(); const oldH = box.scrollHeight, oldTop = box.scrollTop;
    box.textContent = '';
    if (state.hasMore.get(c.id)) {
      const b = el('button', 'load-more', 'پیام‌های قدیمی‌تر'); b.type = 'button'; b.onclick = loadOlder; box.appendChild(b);
    }
    const list = (state.messages.get(c.id) || []).concat([...state.pending.values()].filter(p => p.chatId === c.id));
    let prev = null, lastDay = '';
    for (const m of list) {
      const day = new Date(m.createdAt).toDateString();
      if (day !== lastDay) { box.appendChild(el('div', 'day-sep', dayFmt.format(new Date(m.createdAt)))); lastDay = day; prev = null; }
      box.appendChild(renderMessage(c, m, prev)); prev = m;
    }
    if (toBottom === true || (toBottom !== 'keep' && near)) scrollBottom();
    else if (toBottom === 'keep') box.scrollTop = box.scrollHeight - oldH + oldTop;
  }
  async function loadOlder() {
    const id = state.activeId, list = state.messages.get(id) || [];
    if (!list.length) return;
    const r = await api(`/chats/${id}/messages?limit=50&before=${list[0].id}`);
    state.messages.set(id, r.messages.concat(list)); state.hasMore.set(id, r.hasMore);
    renderMessages('keep');
  }
  function markActiveRead() {
    const c = state.chats.get(state.activeId); if (!c || document.hidden) return;
    const list = state.messages.get(c.id) || []; const last = list[list.length - 1];
    if (!last) return;
    c.unread = 0;
    const me = c.members.find(m => m.id === state.me.id);
    if (me && me.lastReadId >= last.id) return;
    if (me) me.lastReadId = last.id;
    wsSend({ type: 'read', chatId: c.id, messageId: last.id }) || api(`/chats/${c.id}/read`, { method: 'POST', body: { messageId: last.id } }).catch(() => {});
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { markActiveRead(); renderChatList(); } });

  // composer
  const input = $('msg-input');
  function autoGrow() { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 140) + 'px'; }
  let lastTypingSent = 0;
  input.addEventListener('input', () => {
    autoGrow();
    if (Date.now() - lastTypingSent > 3000 && state.activeId) { lastTypingSent = Date.now(); wsSend({ type: 'typing', chatId: state.activeId }); }
  });
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && window.innerWidth > 760) { e.preventDefault(); $('composer').requestSubmit(); }
  });
  $('composer').onsubmit = e => {
    e.preventDefault();
    const text = input.value.trim(); if (!text || !state.activeId) return;
    sendMessage(state.activeId, text, null);
    input.value = ''; autoGrow(); input.focus();
  };
  let seq = 0;
  function sendMessage(chatId, text, file) {
    const clientId = 'c' + Date.now() + '-' + (++seq);
    const p = { id: Number.MAX_SAFE_INTEGER - seq, clientId, chatId, senderId: state.me.id, kind: file ? (file.mime.startsWith('image/') ? 'image' : 'file') : 'text', body: text || '', file, createdAt: Date.now(), pending: true };
    state.pending.set(clientId, p);
    if (state.activeId === chatId) renderMessages(true);
    const payload = { type: 'send', chatId, text, fileId: file ? file.id : null, clientId };
    if (!wsSend(payload)) {
      api(`/chats/${chatId}/messages`, { method: 'POST', body: { text, fileId: payload.fileId } })
        .then(r => onAck({ clientId, message: r.message }))
        .catch(err => { state.pending.delete(clientId); toast(err.message); renderMessages(); });
    }
  }
  function onAck(d) {
    state.pending.delete(d.clientId);
    if (d.message) addMessage(d.message);
  }

  // attachments
  $('btn-attach').onclick = () => $('file-input').click();
  $('file-input').onchange = () => {
    const f = $('file-input').files[0]; $('file-input').value = '';
    if (f && state.activeId) uploadFile(f, state.activeId);
  };
  $('messages').addEventListener('dragover', e => e.preventDefault());
  $('messages').addEventListener('drop', e => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f && state.activeId) uploadFile(f, state.activeId); });
  input.addEventListener('paste', e => { const f = [...(e.clipboardData.files || [])][0]; if (f && state.activeId) { e.preventDefault(); uploadFile(f, state.activeId); } });
  function uploadFile(file, chatId) {
    const fd = new FormData(); fd.append('file', file, file.name);
    const xhr = new XMLHttpRequest();
    const bar = $('upload-bar'), prog = $('upload-progress');
    bar.classList.remove('hidden'); prog.style.width = '0';
    xhr.upload.onprogress = e => { if (e.lengthComputable) prog.style.width = (e.loaded / e.total * 100) + '%'; };
    xhr.onload = () => {
      bar.classList.add('hidden');
      let d = {}; try { d = JSON.parse(xhr.responseText); } catch {}
      if (xhr.status !== 200) return toast(d.error || 'خطا در آپلود');
      const caption = input.value.trim(); input.value = ''; autoGrow();
      sendMessage(chatId, caption, d.file);
    };
    xhr.onerror = () => { bar.classList.add('hidden'); toast('خطا در آپلود'); };
    xhr.open('POST', '/api/upload'); xhr.send(fd);
  }
  $('lightbox').onclick = () => $('lightbox').classList.add('hidden');

  function addMessage(m) {
    const list = state.messages.get(m.chatId);
    if (list && !list.some(x => x.id === m.id)) { list.push(m); list.sort((a, b) => a.id - b.id); }
    const c = state.chats.get(m.chatId);
    if (!c) { refreshChat(m.chatId); return; }
    if (!c.lastMessage || c.lastMessage.id <= m.id) c.lastMessage = m;
    const t = state.typing.get(m.chatId); if (t && t.userId === m.senderId) state.typing.delete(m.chatId);
    if (m.senderId !== state.me.id) {
      if (state.activeId === m.chatId && !document.hidden) markActiveRead();
      else { c.unread = (c.unread || 0) + 1; notify(c, m); }
    }
    if (state.activeId === m.chatId) { renderMessages(m.senderId === state.me.id ? true : undefined); renderHeader(); }
    renderChatList();
  }
  async function refreshChat(id) {
    try { const r = await api(`/chats/${id}`); state.chats.set(id, r.chat); renderChatList(); if (state.activeId === id) { renderHeader(); renderMessages(); } } catch {}
  }
  function notify(c, m) {
    if (!('Notification' in window) || Notification.permission !== 'granted' || !document.hidden) return;
    try { new Notification(c.title, { body: m.kind === 'text' ? m.body : previewText(c), icon: '/icons/icon-192.png', tag: 'chat' + c.id }); } catch {}
  }

  // ---------- websocket ----------
  function wsSend(obj) { if (state.ws && state.ws.readyState === 1) { state.ws.send(JSON.stringify(obj)); return true; } return false; }
  function connectWs() {
    if (!state.me) return;
    const ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws');
    state.ws = ws;
    ws.onopen = () => {
      state.wsRetry = 0; $('conn-dot').classList.add('on'); $('conn-dot').title = 'متصل';
      // resync after reconnect
      loadChats().then(() => {
        for (const [id, list] of state.messages) {
          const last = list[list.length - 1];
          api(`/chats/${id}/messages?limit=200`).then(r => {
            state.messages.set(id, r.messages); state.hasMore.set(id, r.hasMore);
            if (state.activeId === id) { renderMessages(); markActiveRead(); }
          }).catch(() => {});
          void last;
        }
        if (state.activeId) renderHeader();
      }).catch(() => {});
    };
    ws.onmessage = ev => {
      let d; try { d = JSON.parse(ev.data); } catch { return; }
      switch (d.type) {
        case 'message': addMessage(d.message); break;
        case 'ack': onAck(d); break;
        case 'error': if (d.clientId) { state.pending.delete(d.clientId); renderMessages(); } toast(d.error); break;
        case 'chat': {
          const old = state.chats.get(d.chat.id);
          if (old && state.activeId === d.chat.id) d.chat.unread = 0;
          state.chats.set(d.chat.id, d.chat); renderChatList();
          if (state.activeId === d.chat.id) { renderHeader(); renderMessages(); }
          break;
        }
        case 'chatRemoved': state.chats.delete(d.chatId); state.messages.delete(d.chatId); if (state.activeId === d.chatId) $('btn-back').onclick(); renderChatList(); break;
        case 'read': {
          const c = state.chats.get(d.chatId); if (!c) break;
          const m = c.members.find(x => x.id === d.userId); if (m) m.lastReadId = Math.max(m.lastReadId, d.messageId);
          if (d.userId === state.me.id && state.activeId !== d.chatId) { loadChats(); }
          if (state.activeId === d.chatId) renderMessages();
          break;
        }
        case 'presence':
          for (const c of state.chats.values()) for (const m of c.members) if (m.id === d.userId) { m.online = d.online; m.lastSeen = d.lastSeen; }
          renderChatList(); if (state.activeId) renderHeader();
          break;
        case 'user':
          if (d.user.id === state.me.id) { state.me = { ...state.me, ...d.user }; renderMe(); }
          for (const c of state.chats.values()) {
            for (const m of c.members) if (m.id === d.user.id) m.displayName = d.user.displayName;
            if (c.type === 'private' && c.peerId === d.user.id) c.title = d.user.displayName;
          }
          renderChatList(); if (state.activeId) { renderHeader(); renderMessages(); }
          break;
        case 'typing':
          state.typing.set(d.chatId, { userId: d.userId, until: Date.now() + 4000 });
          renderChatList(); if (state.activeId === d.chatId) renderHeader();
          setTimeout(() => { renderChatList(); if (state.activeId) renderHeader(); }, 4100);
          break;
      }
    };
    ws.onclose = ev => {
      $('conn-dot').classList.remove('on'); $('conn-dot').title = 'در حال اتصال…';
      if (state.ws !== ws) return;
      state.ws = null;
      if (ev.code === 4001) { logoutLocal(); return; }
      const delay = Math.min(15000, 1000 * Math.pow(2, state.wsRetry++));
      setTimeout(connectWs, delay);
    };
  }

  // ---------- menu & modals ----------
  $('btn-menu').onclick = e => { e.stopPropagation(); $('menu').classList.toggle('hidden'); };
  document.addEventListener('click', e => { if (!$('menu').contains(e.target)) $('menu').classList.add('hidden'); });
  function openModal(title, build) {
    $('modal-title').textContent = title; const b = $('modal-body'); b.textContent = ''; build(b);
    $('modal').classList.remove('hidden');
  }
  function closeModal() { $('modal').classList.add('hidden'); }
  $('modal-close').onclick = closeModal;
  $('modal').onclick = e => { if (e.target === $('modal')) closeModal(); };
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeModal(); $('lightbox').classList.add('hidden'); } });

  function userRow(u, extra) {
    const r = el('div', 'user-row');
    r.appendChild(avatar(u.displayName, u.id, 'sm' + (u.online ? ' online' : '')));
    const g = el('div', 'grow'); g.append(el('div', null, u.displayName), el('div', 'muted small ltr', toFa(u.phone)));
    r.appendChild(g);
    if (extra) r.appendChild(extra);
    return r;
  }
  function searchBox(container, onPick, placeholder) {
    const inp = el('input'); inp.type = 'search'; inp.placeholder = placeholder || 'شماره موبایل را وارد کنید'; inp.inputMode = 'tel';
    const results = el('div');
    let timer;
    inp.oninput = () => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        results.textContent = '';
        if (inp.value.trim().length < 4) { results.appendChild(el('div', 'muted small', 'حداقل ۴ رقم از شماره را وارد کنید')); return; }
        try {
          const r = await api('/users/search?phone=' + encodeURIComponent(inp.value));
          if (!r.users.length) results.appendChild(el('div', 'muted small', 'کاربری پیدا نشد'));
          r.users.forEach(u => { const row = userRow(u); row.onclick = () => onPick(u, row); results.appendChild(row); });
        } catch (e) { results.appendChild(el('div', 'error', e.message)); }
      }, 250);
    };
    container.append(inp, results);
    setTimeout(() => inp.focus(), 50);
    return inp;
  }
  function newChatModal() {
    $('menu').classList.add('hidden');
    openModal('گفتگوی جدید', body => {
      searchBox(body, async u => {
        try { const r = await api('/chats/private', { method: 'POST', body: { userId: u.id } }); state.chats.set(r.chat.id, r.chat); closeModal(); openChat(r.chat.id); }
        catch (e) { toast(e.message); }
      });
      const g = el('button', 'btn', '👥 ساخت گروه جدید'); g.type = 'button'; g.onclick = newGroupModal; body.appendChild(g);
    });
  }
  function newGroupModal(preset) {
    $('menu').classList.add('hidden');
    const selected = new Map();
    openModal('گروه جدید', body => {
      const lbl = el('label', null, 'نام گروه'); const title = el('input'); title.type = 'text'; title.maxLength = 64; lbl.appendChild(title); body.appendChild(lbl);
      body.appendChild(el('div', 'section-title', 'اعضا'));
      const chips = el('div', 'chips'); body.appendChild(chips);
      const renderChips = () => { chips.textContent = ''; for (const u of selected.values()) { const ch = el('span', 'chip', u.displayName + ' ✕'); ch.onclick = () => { selected.delete(u.id); renderChips(); }; chips.appendChild(ch); } };
      searchBox(body, (u, row) => { if (selected.has(u.id)) selected.delete(u.id); else selected.set(u.id, u); row.classList.toggle('selected', selected.has(u.id)); renderChips(); }, 'جستجوی عضو با شماره موبایل');
      const err = el('div', 'error'); body.appendChild(err);
      const btn = el('button', 'btn primary', 'ساخت گروه'); btn.type = 'button'; body.appendChild(btn);
      btn.onclick = async () => {
        btn.disabled = true;
        try {
          const r = await api('/chats/group', { method: 'POST', body: { title: title.value, memberIds: [...selected.keys()] } });
          state.chats.set(r.chat.id, r.chat); closeModal(); openChat(r.chat.id);
        } catch (e) { err.textContent = e.message; } finally { btn.disabled = false; }
      };
      setTimeout(() => title.focus(), 60);
    });
  }
  function chatInfoModal() {
    const c = state.chats.get(state.activeId); if (!c) return;
    if (c.type === 'private') {
      const p = peerOf(c);
      openModal('اطلاعات کاربر', body => {
        body.appendChild(userRow(p));
        body.appendChild(el('div', 'muted small', p.online ? 'آنلاین' : fmtLastSeen(p.lastSeen)));
      });
      return;
    }
    openModal('اطلاعات گروه', body => {
      const lbl = el('label', null, 'نام گروه'); const t = el('input'); t.type = 'text'; t.value = c.title; t.maxLength = 64; lbl.appendChild(t); body.appendChild(lbl);
      const save = el('button', 'btn', 'ذخیرهٔ نام'); save.type = 'button';
      save.onclick = async () => { try { await api(`/chats/${c.id}`, { method: 'PATCH', body: { title: t.value } }); toast('ذخیره شد'); } catch (e) { toast(e.message); } };
      body.appendChild(save);
      body.appendChild(el('div', 'section-title', `اعضا (${toFa(c.members.length)})`));
      c.members.forEach(m => body.appendChild(userRow(m, m.role === 'admin' ? el('span', 'muted small', 'سازنده') : null)));
      body.appendChild(el('div', 'section-title', 'افزودن عضو'));
      searchBox(body, async u => {
        if (c.members.some(m => m.id === u.id)) return toast('این کاربر عضو گروه است');
        try { const r = await api(`/chats/${c.id}/members`, { method: 'POST', body: { userIds: [u.id] } }); state.chats.set(c.id, r.chat); closeModal(); toast('عضو اضافه شد'); renderHeader(); }
        catch (e) { toast(e.message); }
      }, 'جستجوی کاربر با شماره موبایل');
      const leave = el('button', 'btn danger', 'ترک گروه'); leave.type = 'button';
      leave.onclick = async () => { if (!confirm('از گروه خارج می‌شوید؟')) return; try { await api(`/chats/${c.id}/leave`, { method: 'POST' }); closeModal(); } catch (e) { toast(e.message); } };
      body.appendChild(leave);
    });
  }
  function profileModal() {
    $('menu').classList.add('hidden');
    openModal('پروفایل و تنظیمات', body => {
      body.appendChild(userRow(state.me));
      const l1 = el('label', null, 'نام نمایشی'); const n = el('input'); n.type = 'text'; n.value = state.me.displayName; n.maxLength = 64; l1.appendChild(n); body.appendChild(l1);
      const s1 = el('button', 'btn primary', 'ذخیرهٔ نام'); s1.type = 'button'; body.appendChild(s1);
      s1.onclick = async () => { try { const r = await api('/me', { method: 'PATCH', body: { displayName: n.value } }); state.me = r.user; renderMe(); toast('ذخیره شد'); } catch (e) { toast(e.message); } };
      body.appendChild(el('div', 'section-title', 'تغییر رمز عبور'));
      const o = el('input'); o.type = 'password'; o.placeholder = 'رمز فعلی'; o.autocomplete = 'current-password';
      const p = el('input'); p.type = 'password'; p.placeholder = 'رمز جدید (حداقل ۶ کاراکتر)'; p.autocomplete = 'new-password';
      const s2 = el('button', 'btn', 'تغییر رمز'); s2.type = 'button';
      s2.onclick = async () => { try { await api('/me/password', { method: 'POST', body: { oldPassword: o.value, newPassword: p.value } }); o.value = p.value = ''; toast('رمز عبور تغییر کرد'); } catch (e) { toast(e.message); } };
      body.append(o, p, s2);
      if ('Notification' in window && Notification.permission === 'default') {
        const nb = el('button', 'btn', '🔔 فعال‌سازی اعلان‌ها'); nb.type = 'button'; nb.onclick = () => Notification.requestPermission().then(() => nb.remove()); body.appendChild(nb);
      }
    });
  }
  $('fab').onclick = newChatModal;
  $('m-newchat').onclick = newChatModal;
  $('m-newgroup').onclick = () => newGroupModal();
  $('m-profile').onclick = profileModal;
  $('m-logout').onclick = async () => { $('menu').classList.add('hidden'); await api('/logout', { method: 'POST' }).catch(() => {}); logoutLocal(); };
  $('btn-info').onclick = chatInfoModal;
  $('chat-head-info').onclick = chatInfoModal;
  setInterval(() => { if (state.activeId) renderHeader(); }, 60000);

  // ---------- boot ----------
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
  setMode('login');
  api('/session').then(r => { if (!r.user) throw 0; state.me = r.user; enterApp(); })
    .catch(() => { $('auth').classList.remove('hidden'); });
  void faNum;
})();
