#!/bin/sh
# ساخت گواهی خودامضا برای آرمینگرام (کاملاً آفلاین)
# استفاده: ./scripts/self-signed-cert.sh chat.example.ir   یا   ./scripts/self-signed-cert.sh 185.1.2.3
set -e
NAME="${1:?domain or IP required}"
OUT="$(dirname "$0")/../deploy/certs"
mkdir -p "$OUT"
case "$NAME" in
  *[!0-9.]*) SAN="DNS:$NAME" ;;
  *) SAN="IP:$NAME" ;;
esac
openssl req -x509 -newkey rsa:2048 -sha256 -days 3650 -nodes \
  -keyout "$OUT/key.pem" -out "$OUT/cert.pem" \
  -subj "/CN=$NAME" -addext "subjectAltName=$SAN"
chmod 644 "$OUT/cert.pem"; chmod 600 "$OUT/key.pem"
echo "گواهی ساخته شد: $OUT/cert.pem و $OUT/key.pem (اعتبار ۱۰ سال)"
