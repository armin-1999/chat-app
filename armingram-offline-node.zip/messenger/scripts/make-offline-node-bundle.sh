#!/bin/sh
# ساخت بستهٔ آفلاین «بدون Docker»: کد + node_modules (همه وابستگی‌ها) در یک فایل zip.
# چون آرمینگرام هیچ ماژول native ندارد، همین node_modules روی ویندوز، لینوکس و مک کار می‌کند.
# روی سیستمی با اینترنت اجرا کنید؛ خروجی: armingram-offline-node.zip
set -e
cd "$(dirname "$0")/.."
npm ci --omit=dev
cd ..
NAME="$(basename "$OLDPWD")"
rm -f armingram-offline-node.zip
zip -qr armingram-offline-node.zip "$NAME" -x "$NAME/data/*" "$NAME/backups/*" "$NAME/*.zip" "$NAME/*.tar.gz" "$NAME/test/*"
echo "آماده است: $(pwd)/armingram-offline-node.zip"
echo "نصب‌کنندهٔ Node.js (نسخهٔ 24 LTS) را هم از nodejs.org دانلود و کنار این فایل نگه دارید."
