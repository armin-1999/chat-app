#!/bin/sh
# بازگردانی پشتیبان آرمینگرام
# استفاده: ./scripts/restore.sh backups/armingram-YYYYMMDD-HHMMSS.tar.gz
set -e
cd "$(dirname "$0")/.."
FILE="${1:?backup file required}"
docker compose stop armingram 2>/dev/null || true
mkdir -p data && TMPD="$(mktemp -d)"
tar xzf "$FILE" -C "$TMPD"
DB="$(ls "$TMPD"/backup-*.db | head -1)"
[ -f data/messenger.db ] && mv data/messenger.db "data/messenger.db.before-restore-$(date +%s)"
rm -f data/messenger.db-wal data/messenger.db-shm
cp "$DB" data/messenger.db
rm -rf data/uploads && cp -r "$TMPD/uploads" data/uploads
[ -f "$TMPD/jwt_secret" ] && cp "$TMPD/jwt_secret" data/jwt_secret
rm -rf "$TMPD"
chown -R 1000:1000 data 2>/dev/null || true
docker compose start armingram 2>/dev/null || true
echo "بازگردانی انجام شد."
