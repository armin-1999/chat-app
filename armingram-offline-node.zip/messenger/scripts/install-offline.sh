#!/bin/sh
# نصب آفلاین روی سرور (بدون اینترنت بین‌الملل). Docker باید از قبل نصب باشد.
# استفاده: داخل پوشهٔ استخراج‌شده از armingram-offline.tar.gz اجرا کنید.
set -e
cd "$(dirname "$0")/.."
gunzip -c offline/armingram-images.tar.gz | docker load
[ -f .env ] || cp .env.example .env
mkdir -p data && chown -R 1000:1000 data 2>/dev/null || true
echo "image ها بارگذاری شدند. حالا .env را ویرایش و اجرا کنید:  docker compose up -d --no-build"
