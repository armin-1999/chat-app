#!/bin/sh
# ساخت بستهٔ نصب آفلاین (روی سیستمی که به اینترنت دسترسی دارد اجرا کنید)
# خروجی: armingram-offline.tar.gz شامل image های Docker + کد + فایل‌های استقرار
set -e
cd "$(dirname "$0")/.."
docker build -t armingram:latest .
docker pull caddy:2-alpine
mkdir -p offline
docker save armingram:latest caddy:2-alpine | gzip > offline/armingram-images.tar.gz
tar czf armingram-offline.tar.gz --exclude=./node_modules --exclude=./data --exclude=./backups \
  --exclude=./armingram-offline.tar.gz --exclude='./*.zip' .
rm -rf offline
echo "آماده است: armingram-offline.tar.gz  ->  این فایل را به سرور ایران منتقل کنید."
