#!/bin/sh
# پشتیبان‌گیری از آرمینگرام: پایگاه داده (به‌صورت امن، حین اجرا) + فایل‌های آپلودشده
# استفاده: ./scripts/backup.sh [پوشهٔ مقصد]     (پیش‌فرض: ./backups)
# کرون روزانه، ساعت ۳ بامداد:
#   0 3 * * * cd /opt/armingram && ./scripts/backup.sh >> backups/backup.log 2>&1
set -e
cd "$(dirname "$0")/.."
DEST="${1:-./backups}"
STAMP="$(date +%Y%m%d-%H%M%S)"
mkdir -p "$DEST"
TMP="./data/backup-$STAMP.db"
# VACUUM INTO یک کپی سازگار از دیتابیس می‌سازد، حتی وقتی برنامه در حال اجراست.
if docker ps --format '{{.Names}}' 2>/dev/null | grep -qx armingram; then
  docker exec armingram node -e "const {DatabaseSync}=require('node:sqlite');new DatabaseSync('/data/messenger.db').exec(\"VACUUM INTO '/data/backup-$STAMP.db'\")"
else
  node -e "const {DatabaseSync}=require('node:sqlite');new DatabaseSync('./data/messenger.db').exec(\"VACUUM INTO '$TMP'\")"
fi
tar czf "$DEST/armingram-$STAMP.tar.gz" -C ./data "backup-$STAMP.db" uploads jwt_secret 2>/dev/null || \
tar czf "$DEST/armingram-$STAMP.tar.gz" -C ./data "backup-$STAMP.db" uploads
rm -f "$TMP"
# نگه‌داشتن ۱۴ پشتیبان آخر
ls -1t "$DEST"/armingram-*.tar.gz 2>/dev/null | tail -n +15 | xargs -r rm -f
echo "پشتیبان ساخته شد: $DEST/armingram-$STAMP.tar.gz"
